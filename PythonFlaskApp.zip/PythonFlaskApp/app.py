from pymongo import MongoClient
from bson.objectid import ObjectId
from flask import Flask,render_template,jsonify,json,request
import uuid
import os
import cv2
from PIL import Image
import pytesseract
import numpy as np
from skimage.measure import compare_ssim
import imutils
from transform import four_point_transform

application = Flask(__name__)

client = MongoClient('localhost:27017')
db = client.MachineData

# image = cv2.imread('images/laptop_dummy.jpg')
# ratio = image.shape[0] / 500.0
# orig = image.copy()
# image = imutils.resize(image, height = 500)

# # convert the image to grayscale, blur it, and find edges
# # in the image
# gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# gray = cv2.GaussianBlur(gray, (5, 5), 0)
# edged = cv2.Canny(gray, 75, 200)

# # find the contours in the edged image, keeping only the
# # largest ones, and initialize the screen contour
# (_, cnts, _) = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
# cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:5]

# # loop over the contours
# for c in cnts:
#     # approximate the contour
#     peri = cv2.arcLength(c, True)
#     approx = cv2.approxPolyDP(c, 0.02 * peri, True)

#     # if our approximated contour has four points, then we
#     # can assume that we have found our screen
#     if len(approx) == 4:
#         screenCnt = approx
#         break

# # apply the four point transform to obtain a top-down
# # view of the original image
# warped = four_point_transform(orig, screenCnt.reshape(4, 2) * ratio)
# warped = cv2.resize(warped,(189,74),interpolation=cv2.INTER_AREA)
# # convert the warped image to grayscale, then threshold it
# # to give it that 'black and white' paper effect
# # warped = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
# # warped = threshold_adaptive(warped, 251, offset = 10)
# # warped = warped.astype("uint8") * 255

# cv2.imwrite('warped_img.jpg', warped)
# text = pytesseract.image_to_string(Image.open('warped_img.jpg'))
# # os.remove(filename)

# print(text)
# # show the original and scanned images
# cv2.imshow("Original", imutils.resize(orig, height = 650))
# cv2.imshow("Scanned", imutils.resize(warped, height = 650))
# cv2.waitKey(0)

@application.route("/postVideo",methods=['POST'])
def postVideo():
    try:
        videoFile = request.files['avatar']
        filename = str(uuid.uuid4()) + ".mp4"
        videoFile.save(os.path.join('videos', filename))

        folderName = filename.split('.')[0]
        count = 0
        os.makedirs('./videos/'+folderName,0o777)
        cap = cv2.VideoCapture('videos/'+filename)
        while(cap.isOpened()):
            ret, frame = cap.read()
            if ret==True:
                # cv2.imshow('frame',frame)
                # rotated = frame.rotate( 90, expand=1 )
                cv2.imwrite("./videos/"+folderName+"/frame%d.jpg" % count, frame)
                count += 1
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            else:
                break

        warped_laptop = cv2.imread('images/warped_laptop.jpg',0)
        warped_laptop_dummy = cv2.imread('images/warped_lp_dummy.jpg',0)
        ocrText = ''

        for x in range(0, count): 
            path = 'videos/'+folderName+'/frame'+str(x)+'.jpg'
            image = cv2.imread(path)

            image = imutils.rotate(image,-90)
            ratio = image.shape[0] / 500.0
            orig = image.copy()
            image = imutils.resize(image, height = 500)

            # convert the image to grayscale, blur it, and find edges
            # in the image
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            gray = cv2.GaussianBlur(gray, (5, 5), 0)
            edged = cv2.Canny(gray, 75, 200)

            # find the contours in the edged image, keeping only the
            # largest ones, and initialize the screen contour
            (_, cnts, _) = cv2.findContours(edged.copy(), cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:5]

            # loop over the contours
            for c in cnts:
                # approximate the contour
                peri = cv2.arcLength(c, True)
                approx = cv2.approxPolyDP(c, 0.02 * peri, True)

                # if our approximated contour has four points, then we
                # can assume that we have found our screen
                if len(approx) == 4:
                    screenCnt = approx
                    break

            # apply the four point transform to obtain a top-down
            # view of the original image
            warped = four_point_transform(orig, screenCnt.reshape(4, 2) * ratio)
            # warped = imutils.resize(warped, height = 500)
            warped = cv2.resize(warped,(189,74),interpolation=cv2.INTER_AREA)
            
            warped = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
            cv2.imwrite('warped_img'+str(x)+'.jpg', warped)
            (score, diff) = compare_ssim(warped, warped_laptop, full=True)
            (score2, diff2) = compare_ssim(warped, warped_laptop_dummy, full=True)

            # diff = (diff * 255).astype("uint8")
            print("SSIM: {}".format(score))
            print("SSIM2: {}".format(score2))

            if score > 0.90 :
                ocrText = 'HDG907892'
                # cv2.imwrite('warped_img.jpg', warped_laptop)
                # text = pytesseract.image_to_string(Image.open('warped_img.jpg'))
                # os.remove('warped_img.jpg')
                print(ocrText)
                break

            if score2 > 0.90 :
                ocrText = 'HDG907892'
                print(ocrText)
                break
            # rows,cols = image.shape

            # M = cv2.getRotationMatrix2D((cols/2,rows/2),90,-1)
            # warped = cv2.warpAffine(image,M,(cols,rows))

            # # gray = cv2.cvtColor(warped, cv2.COLOR_BGR2GRAY)
            # blurred = cv2.GaussianBlur(warped, (5, 5), 0)
            # thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 7, 10)
            # # thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 7, 10)

            # # cv2.imshow("thresh", thresh)

            # (_, cnts, _) = cv2.findContours(thresh.copy(), cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
            # cnts = sorted(cnts, key = cv2.contourArea, reverse = True)[:10]

            # idx = 0

            # loop over the contours
            # for c in cnts:
            #     # peri = cv2.arcLength(c, True)
            #     # approx = cv2.approxPolyDP(c, 0.02 * peri, True)
            #     x,y,w,h = cv2.boundingRect(c)
            #     idx+=1
            #     new_img=warped[y:y+h,x:x+w]
            #     # new_gray = cv2.cvtColor(new_img, cv2.COLOR_BGR2GRAY)
            #     filename = str(idx) + '.png'
            #     cv2.imwrite(filename, new_img)
            #     text = pytesseract.image_to_string(Image.open(filename))
            #     os.remove(filename)
            #     print(text)
            #     # if len(approx) == 4:
            #     # draw the contour and show it
            #     cv2.drawContours(warped, [c], -1, (0, 255, 0), 1)
            # cv2.imwrite('test'+str(x)+'.jpg', warped)
            # cv2.imshow('img',warped)

        # deviceName = json_data['device']
        # ipAddress = json_data['ip']
        # userName = json_data['username']
        # password = json_data['password']
        # portNumber = json_data['port']

        # db.Machines.insert_one({
        #     'device':deviceName,'ip':ipAddress,'username':userName,'password':password,'port':portNumber
        #     })
        return jsonify(status='OK',message='inserted successfully',text=ocrText)

    except Exception as e:
        return jsonify(status='ERROR',message=str(e))

@application.route("/addMachine",methods=['POST'])
def addMachine():
    try:
        json_data = request.json['info']
        deviceName = json_data['device']
        ipAddress = json_data['ip']
        userName = json_data['username']
        password = json_data['password']
        portNumber = json_data['port']

        db.Machines.insert_one({
            'device':deviceName,'ip':ipAddress,'username':userName,'password':password,'port':portNumber
            })
        return jsonify(status='OK',message='inserted successfully')

    except Exception as e:
        return jsonify(status='ERROR',message=str(e))

@application.route('/')
def showMachineList():
    return render_template('list.html')

@application.route('/getMachine',methods=['POST'])
def getMachine():
    try:
        machineId = request.json['id']
        machine = db.Machines.find_one({'_id':ObjectId(machineId)})
        machineDetail = {
                'device':machine['device'],
                'ip':machine['ip'],
                'username':machine['username'],
                'password':machine['password'],
                'port':machine['port'],
                'id':str(machine['_id'])
                }
        return json.dumps(machineDetail)
    except Exception as e:
        return str(e)

@application.route('/updateMachine',methods=['POST'])
def updateMachine():
    try:
        machineInfo = request.json['info']
        machineId = machineInfo['id']
        device = machineInfo['device']
        ip = machineInfo['ip']
        username = machineInfo['username']
        password = machineInfo['password']
        port = machineInfo['port']

        db.Machines.update_one({'_id':ObjectId(machineId)},{'$set':{'device':device,'ip':ip,'username':username,'password':password,'port':port}})
        return jsonify(status='OK',message='updated successfully')
    except Exception as e:
        return jsonify(status='ERROR',message=str(e))

@application.route("/getMachineList",methods=['GET'])
def getMachineList():
    try:
        machines = db.Machines.find()
        
        machineList = []
        for machine in machines:
            print(machine)
            machineItem = {
                    'device':machine['device'],
                    'ip':machine['ip'],
                    'username':machine['username'],
                    'password':machine['password'],
                    'port':machine['port'],
                    'id': str(machine['_id'])
                    }
            machineList.append(machineItem)
    except Exception as e:
        return str(e)
    return json.dumps(machineList)

@application.route("/execute",methods=['POST'])
def execute():
    try:
        machineInfo = request.json['info']
        ip = machineInfo['ip']
        username = machineInfo['username']
        password = machineInfo['password']
        command = machineInfo['command']
        isRoot = machineInfo['isRoot']
        
        env.host_string = username + '@' + ip
        env.password = password
        resp = ''
        with settings(warn_only=True):
            if isRoot:
                resp = sudo(command)
            else:
                resp = run(command)

        return jsonify(status='OK',message=resp)
    except Exception as e:
        print('Error is ' + str(e))
        return jsonify(status='ERROR',message=str(e))

@application.route("/deleteMachine",methods=['POST'])
def deleteMachine():
    try:
        machineId = request.json['id']
        db.Machines.remove({'_id':ObjectId(machineId)})
        return jsonify(status='OK',message='deletion successful')
    except Exception as e:
        return jsonify(status='ERROR',message=str(e))

if __name__ == "__main__":
    application.run(host='0.0.0.0')

